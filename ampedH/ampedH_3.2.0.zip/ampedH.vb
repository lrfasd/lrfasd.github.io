﻿Option Explicit On
Option Strict Off

Imports System.Data
Imports System.Windows.Shell
Imports System.Windows.Interop
Imports System.Runtime.InteropServices
Imports System.Windows.Threading
Imports System.Windows.Media.Effects

Class ampedH
    Inherits AeroWindow

    Private IsExtend As Boolean = False
    Private IsVerify As Boolean = False
    Private IsNeedVerify As Boolean = False
    Private IsAcive As Boolean = False
    Private RefreshTimer As DispatcherTimer = New DispatcherTimer
    Private StackPanel As StackPanel = New StackPanel
    Private NotifyIcon As Forms.NotifyIcon
    Private NotifyIconMenu As Forms.ContextMenu
    Private NotifyIconTimer As DispatcherTimer = New DispatcherTimer
    Private IsNotifyIconLeftMouseDown = False
    Private IsNotifyIconPreviewShow = False
    Private WindowClassList As String()
    Private WindowTitleList As String()
    Private PreviewSize As Double
    Private PreviewTopmost As Boolean
    Private Funcs As Dictionary(Of String, Dictionary(Of String, List(Of Param))) = New Dictionary(Of String, Dictionary(Of String, List(Of Param)))
    Private Infos As Info()
    Private Fore As IntPtr = IntPtr.Zero
    Private Origin As IntPtr = IntPtr.Zero

    Public Sub New(Optional ByVal IsExtend As Boolean = False)
        CheckSingle()
        Me.IsExtend = IsExtend
        Me.Width = 400
        Me.Height = 0
        Me.Title = "ampedH"
        Me.Icon = BitmapFrame.Create(New Uri("pack://application:,,,/ampedH.ico", UriKind.RelativeOrAbsolute))
        Me.ResizeMode = Windows.ResizeMode.NoResize
        Me.WindowStartupLocation = WindowStartupLocation.CenterScreen
        Me.WindowStyle = Windows.WindowStyle.ToolWindow
        Me.ShowInTaskbar = False
        Me.Topmost = True
        Me.TaskbarItemInfo = New TaskbarItemInfo
        ReadConfig()
        LoadControl()
        SetJumpList()
        ReDim Infos(0 To -1)
    End Sub
    Private Sub CheckSingle()
        Dim Processes As Process() = Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName)
        If Processes.Length > 1 Then
            Dim Handle As IntPtr = FindWindowEx(IntPtr.Zero, IntPtr.Zero, vbNullString, Process.GetCurrentProcess.ProcessName)
            If Handle <> IntPtr.Zero Then
                SetWindowShow(Handle, True)
                If IsIconic(Handle) Then
                    SetWindowRestore(Handle)
                Else
                    SetForegroundWindow(Handle)
                End If
                ExitMe()
            End If
        End If
    End Sub
    Private Sub ReadConfig()
        Dim Reader As IniReader = New IniReader(Environment.CurrentDirectory & "\ampedH.ini")
        If IsNeedVerify Then
            IsVerify = GetVerifyResult(Reader.ReadString("Verify", "CodeList"))
        Else
            IsVerify = True
        End If
        If IsVerify Then
            WindowClassList = Reader.ReadString("Config", "WindowClassList", "runtimetest_win").Split(",")
            WindowTitleList = Reader.ReadString("Config", "WindowTitleList", "新热血英豪,GetApmed,겟앰프드,????").Split(",")
            PreviewSize = Reader.ReadFloat("Config", "PreviewSize", 0.25)
            PreviewTopmost = (Reader.ReadInteger("Config", "PreviewTopmost", 1) > 0)
            RefreshTimer.Interval = New TimeSpan(Reader.ReadInteger("Config", "RefreshInterval", 200) * 10000)
            Dim Scripts As Dictionary(Of String, String) = New Dictionary(Of String, String)
            Scripts.Add("640×480", "个人小屋:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0201_0_0x00A000D0,0x0201_0_0x00A000D0,0x0202_0_0x00A000D0,0x0202_0_0x00A000D0,,0x0100_0x00010041_0,,,0x0101_0x00010041_0,,0x0201_0_0x00A000D0,0x0201_0_0x00A000D0,0x0202_0_0x00A000D0,0x0202_0_0x00A000D0,,,,,,,0x0201_0_0x00A000D0,0x0201_0_0x00A000D0,0x0202_0_0x00A000D0,0x0202_0_0x00A000D0,|无人岛:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0100_0x79_0,0x0100_0x79_0,0x0101_0x79_0,0x0101_0x79_0,,0x0201_0_0x00400040,0x0201_0_0x00400040,0x0202_0_0x00400040,0x0202_0_0x00400040,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x01600060,0x0201_0_0x01600060,0x0202_0_0x01600060,0x0202_0_0x01600060,,0x0100_0x0D_0,0x0100_0x0D_0,0x0101_0x0D_0,0x0101_0x0D_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x01300130,0x0201_0_0x01300130,0x0202_0_0x01300130,0x0202_0_0x01300130,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,")
            Scripts.Add("800×600", "个人小屋:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0201_0_0x00D00100,0x0201_0_0x00D00100,0x0202_0_0x00D00100,0x0202_0_0x00D00100,,0x0100_0x00010041_0,,,0x0101_0x00010041_0,,0x0201_0_0x00D00100,0x0201_0_0x00D00100,0x0202_0_0x00D00100,0x0202_0_0x00D00100,,,,,,,0x0201_0_0x00D00100,0x0201_0_0x00D00100,0x0202_0_0x00D00100,0x0202_0_0x00D00100,|无人岛:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0100_0x79_0,0x0100_0x79_0,0x0101_0x79_0,0x0101_0x79_0,,0x0201_0_0x00500040,0x0201_0_0x00500040,0x0202_0_0x00500040,0x0202_0_0x00500040,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x01C000E0,0x0201_0_0x01C000E0,0x0202_0_0x01C000E0,0x0202_0_0x01C000E0,,0x0100_0x0D_0,0x0100_0x0D_0,0x0101_0x0D_0,0x0101_0x0D_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x01800190,0x0201_0_0x01800190,0x0202_0_0x01800190,0x0202_0_0x01800190,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,")
            Scripts.Add("1024×768", "个人小屋:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0201_0_0x01000150,0x0201_0_0x01000150,0x0202_0_0x01000150,0x0202_0_0x01000150,,0x0100_0x00010041_0,,,0x0101_0x00010041_0,,0x0201_0_0x01000150,0x0201_0_0x01000150,0x0202_0_0x01000150,0x0202_0_0x01000150,,,,,,,0x0201_0_0x01000150,0x0201_0_0x01000150,0x0202_0_0x01000150,0x0202_0_0x01000150,|无人岛:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0100_0x79_0,0x0100_0x79_0,0x0101_0x79_0,0x0101_0x79_0,,0x0201_0_0x00600050,0x0201_0_0x00600050,0x0202_0_0x00600050,0x0202_0_0x00600050,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x02400090,0x0201_0_0x02400090,0x0202_0_0x02400090,0x0202_0_0x02400090,,0x0100_0x0D_0,0x0100_0x0D_0,0x0101_0x0D_0,0x0101_0x0D_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x01E00200,0x0201_0_0x01E00200,0x0202_0_0x01E00200,0x0202_0_0x01E00200,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,")
            Scripts.Add("1280×960", "个人小屋:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0201_0_0x014001B0,0x0201_0_0x014001B0,0x0202_0_0x014001B0,0x0202_0_0x014001B0,,0x0100_0x00010041_0,,,0x0101_0x00010041_0,,0x0201_0_0x014001B0,0x0201_0_0x014001B0,0x0202_0_0x014001B0,0x0202_0_0x014001B0,,,,,,,0x0201_0_0x014001B0,0x0201_0_0x014001B0,0x0202_0_0x014001B0,0x0202_0_0x014001B0,|无人岛:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0100_0x79_0,0x0100_0x79_0,0x0101_0x79_0,0x0101_0x79_0,,0x0201_0_0x00800050,0x0201_0_0x00800050,0x0202_0_0x00800050,0x0202_0_0x00800050,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x02D000E0,0x0201_0_0x02D000E0,0x0202_0_0x02D000E0,0x0202_0_0x02D000E0,,0x0100_0x0D_0,0x0100_0x0D_0,0x0101_0x0D_0,0x0101_0x0D_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x02600280,0x0201_0_0x02600280,0x0202_0_0x02600280,0x0202_0_0x02600280,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,")
            Scripts.Add("1280×720", "个人小屋:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0201_0_0x01000200,0x0201_0_0x01000200,0x0202_0_0x01000200,0x0202_0_0x01000200,,0x0100_0x00010041_0,,,0x0101_0x00010041_0,,0x0201_0_0x01000200,0x0201_0_0x01000200,0x0202_0_0x01000200,0x0202_0_0x01000200,,,,,,,0x0201_0_0x01000200,0x0201_0_0x01000200,0x0202_0_0x01000200,0x0202_0_0x01000200,|无人岛:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0100_0x79_0,0x0100_0x79_0,0x0101_0x79_0,0x0101_0x79_0,,0x0201_0_0x00500040,0x0201_0_0x00500040,0x0202_0_0x00500040,0x0202_0_0x00500040,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x01C000E0,0x0201_0_0x01C000E0,0x0202_0_0x01C000E0,0x0202_0_0x01C000E0,,0x0100_0x0D_0,0x0100_0x0D_0,0x0101_0x0D_0,0x0101_0x0D_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x01B00280,0x0201_0_0x01B00280,0x0202_0_0x01B00280,0x0202_0_0x01B00280,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,")
            Scripts.Add("1600×900", "个人小屋:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0201_0_0x01300200,0x0201_0_0x01300200,0x0202_0_0x01300200,0x0202_0_0x01300200,,0x0100_0x00010041_0,,,0x0101_0x00010041_0,,0x0201_0_0x01300200,0x0201_0_0x01300200,0x0202_0_0x01300200,0x0202_0_0x01300200,,,,,,,0x0201_0_0x01300200,0x0201_0_0x01300200,0x0202_0_0x01300200,0x0202_0_0x01300200,|无人岛:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0100_0x79_0,0x0100_0x79_0,0x0101_0x79_0,0x0101_0x79_0,,0x0201_0_0x00600050,0x0201_0_0x00600050,0x0202_0_0x00600050,0x0202_0_0x00600050,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x023000B0,0x0201_0_0x023000B0,0x0202_0_0x023000B0,0x0202_0_0x023000B0,,0x0100_0x0D_0,0x0100_0x0D_0,0x0101_0x0D_0,0x0101_0x0D_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x02200320,0x0201_0_0x02200320,0x0202_0_0x02200320,0x0202_0_0x02200320,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,")
            Scripts.Add("1920×1080", "个人小屋:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0201_0_0x01700280,0x0201_0_0x01700280,0x0202_0_0x01700280,0x0202_0_0x01700280,,0x0100_0x00010041_0,,,0x0101_0x00010041_0,,0x0201_0_0x01700280,0x0201_0_0x01700280,0x0202_0_0x01700280,0x0202_0_0x01700280,,,,,,,0x0201_0_0x01700280,0x0201_0_0x01700280,0x0202_0_0x01700280,0x0202_0_0x01700280,|无人岛:0x0100_0x1B_0,0x0100_0x1B_0,0x0101_0x1B_0,0x0101_0x1B_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0100_0x79_0,0x0100_0x79_0,0x0101_0x79_0,0x0101_0x79_0,,0x0201_0_0x00700060,0x0201_0_0x00700060,0x0202_0_0x00700060,0x0202_0_0x00700060,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x02A000D0,0x0201_0_0x02A000D0,0x0202_0_0x02A000D0,0x0202_0_0x02A000D0,,0x0100_0x0D_0,0x0100_0x0D_0,0x0101_0x0D_0,0x0101_0x0D_0,,0x0100_0x78_0,0x0101_0x78_0,,,,0x0201_0_0x029003C0,0x0201_0_0x029003C0,0x0202_0_0x029003C0,0x0202_0_0x029003C0,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,,0x0100_0x78_0,0x0101_0x78_0,,,,,,,,")
            Scripts = Reader.ReadAllSection("Script", Scripts)
            For i As Integer = 0 To Scripts.Count - 1
                AddFunc(Scripts.Keys(i), Scripts.Values(i))
            Next
        End If
    End Sub
    Private Sub AddFunc(ByVal Size As String, ByVal Script As String)
        If Not Funcs.ContainsKey(Size) Then
            Dim Scripts As String() = CStr(IIf(Script <> "", "|" & Script, "")).Split("|")
            Dim Dictionary As Dictionary(Of String, List(Of Param)) = New Dictionary(Of String, List(Of Param))
            For j As Integer = 0 To Scripts.Length - 1
                If Scripts(j) = "" Then
                    Scripts(j) = ":"
                End If
                Dim l As Integer = InStr(Scripts(j), ":")
                If l > 0 Then
                    Dim n As String = Mid(Scripts(j), 1, l - 1)
                    Dim s As String() = Mid(Scripts(j), l + 1, Scripts(j).Length - l).Split(",")
                    Dim List As List(Of Param) = New List(Of Param)
                    For k As Integer = 0 To s.Length - 1
                        Dim p As String() = s(k).Split("_")
                        Dim Param1 As Integer = 0
                        If p.Length > 0 Then Param1 = StringToInteger(p(0))
                        Dim Param2 As Integer = 0
                        If p.Length > 1 Then Param2 = StringToInteger(p(1))
                        Dim Param3 As Integer = 0
                        If p.Length > 2 Then Param3 = StringToInteger(p(2))
                        List.Add(New Param(Param1, Param2, Param3))
                    Next
                    Dictionary.Add(n, List)
                End If
            Next
            Funcs.Add(Size, Dictionary)
        End If
    End Sub
    Private Sub LoadControl()
        AddHandler RefreshTimer.Tick, AddressOf RefreshTimer_Tick
        Me.Content = StackPanel
        NotifyIcon = New Forms.NotifyIcon()
        NotifyIcon.Icon = New System.Drawing.Icon(Application.GetResourceStream(New Uri("pack://application:,,,/ampedH.ico", UriKind.RelativeOrAbsolute)).Stream)
        AddHandler NotifyIcon.MouseMove, AddressOf NotifyIcon_MouseMove
        AddHandler NotifyIcon.MouseDown, AddressOf NotifyIcon_MouseDown
        AddHandler NotifyIcon.MouseClick, AddressOf NotifyIcon_MouseClick
        NotifyIcon.Visible = True
        NotifyIconMenu = New Forms.ContextMenu()
        NotifyIcon.ContextMenu = NotifyIconMenu
        AddHandler NotifyIconTimer.Tick, AddressOf NotifyIconTimer_Tick
    End Sub
    Private Sub SetJumpList()
        Const p As String = "C:\Program Files\Internet Explorer\iexplore.exe"
        Dim j As JumpList = New JumpList
        j.JumpItems.Add(New JumpTask With {.CustomCategory = "链接", .Title = "加入QQ交流群", .Description = "加入QQ交流群", .ApplicationPath = "http://shang.qq.com/wpa/qunwpa?idkey=11334256789a3e86e679f77ae86fb5f26d9e3baaff07f166f653df49a745a0f1", .IconResourcePath = p})
        j.JumpItems.Add(New JumpTask With {.CustomCategory = "链接", .Title = "联系作者QQ", .Description = "联系作者QQ", .ApplicationPath = "http://wpa.qq.com/msgrd?v=3&uin=308973930&site=ampedH&menu=yes", .IconResourcePath = p})
        JumpList.SetJumpList(Global.ampedH.Application.Current, j)
    End Sub

    Private Sub NotifyIcon_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        If Not IsNotifyIconLeftMouseDown Then
            IsAcive = (GetForegroundWindow() = New WindowInteropHelper(Me).Handle)
        End If
        If Not IsNotifyIconPreviewShow AndAlso IsShiftDown() Then
            ShowAllPreview()
            NotifyIconTimer.Start()
        End If
    End Sub
    Private Sub NotifyIcon_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        If e.Button = Forms.MouseButtons.Left Then
            IsNotifyIconLeftMouseDown = True
        End If
    End Sub
    Private Sub NotifyIcon_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        IsNotifyIconLeftMouseDown = False
        If e.Button = Forms.MouseButtons.Left Then
            Dim Handle As IntPtr = New WindowInteropHelper(Me).Handle
            If IsWindowVisible(Handle) Then
                If IsAcive Then
                    CloseMe()
                Else
                    SetForegroundWindow(Handle)
                End If
            Else
                ShowMe()
            End If
        End If
    End Sub
    Private Sub ShowAllPreview()
        Dim Position As POINT = GetMousePosition()
        Dim X As Integer = Position.X
        Dim Y As Integer = Position.Y - 20
        For i As Integer = StackPanel.Children.Count - 1 To 0 Step -1
            Dim GlowTextBlock As GlowTextBlock = CType(StackPanel.Children(i), GlowTextBlock)
            If Not GlowTextBlock.Preview Is Nothing Then
                If Not GlowTextBlock.Preview.IsVisible Then
                    Y -= GlowTextBlock.Preview.Height
                    GlowTextBlock.Preview.IsHitTestVisible = False
                    GlowTextBlock.Preview.ShowPreview(X - GlowTextBlock.Preview.Width, Y)
                    IsNotifyIconPreviewShow = True
                End If
            End If
        Next
    End Sub
    Private Sub HideAllPreview()
        For i As Integer = 0 To StackPanel.Children.Count - 1
            Dim GlowTextBlock As GlowTextBlock = CType(StackPanel.Children(i), GlowTextBlock)
            If Not GlowTextBlock.Preview Is Nothing Then
                If GlowTextBlock.Preview.IsVisible Then
                    If Not GlowTextBlock.Preview.IsHitTestVisible Then
                        GlowTextBlock.Preview.Hide()
                    End If
                End If
            End If
        Next
        IsNotifyIconPreviewShow = False
    End Sub
    Private Sub NotifyIconTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs)
        If Not IsShiftDown() Then
            NotifyIconTimer.Stop()
            HideAllPreview()
        End If
    End Sub

    Private Sub Me_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Me.Closing
        If IsVerify Then
            CloseMe()
            e.Cancel = True
        Else
            ExitMe()
        End If
    End Sub
    Private Sub ShowAbout()
        If Not IsWindowVisible(New WindowInteropHelper(Me).Handle) Then
            ShowMe()
        End If
        Dim Dialog As AeroWindow = New AeroWindow
        Dialog.Owner = Me
        Dialog.Width = 400
        Dialog.Height = 262
        Dialog.Title = Me.Title + "关于"
        Dialog.Icon = Me.Icon
        Dialog.ResizeMode = Windows.ResizeMode.NoResize
        Dialog.WindowStartupLocation = WindowStartupLocation.CenterScreen
        Dialog.WindowStyle = Windows.WindowStyle.ToolWindow
        Dialog.ShowInTaskbar = False
        Dialog.Content = New GlowTextBlock("运行本工具后，会自行监测游戏窗体，支持多个窗体各自实现功能。" & vbCrLf & "　　所实现的功能可从ampedH.ini中重定义。" & vbCrLf & "隐藏本工具后，再次运行exe后可重新显示。" & vbCrLf & "窗体信息列表中" & vbCrLf & "　　鼠标右键、扩展键1单击：顺序切换功能" & vbCrLf & "　　鼠标左键、扩展键2单击：逆序切换功能" & vbCrLf & "　　鼠标中键单击：隐藏/显示窗体" & vbCrLf & "　　上述任意按键三击：强制关闭窗体" & vbCrLf & "　　按住Shift键隐藏窗体为模拟隐藏" & vbCrLf & "★系统开启Aero效果后将支持" & vbCrLf & "　　窗体毛玻璃界面" & vbCrLf & "　　按住Shift键鼠标悬浮于窗体信息上时显示相应窗体实时预览。" & vbCrLf & "　　按住Shift键鼠标悬浮于通知图比上时显示所有窗体实时预览。" & vbCrLf & "　　鼠标左右键同时单击窗体信息可显示相应窗体实时预览浮窗。" & vbCrLf & "　　　　预览浮窗通过同时按住鼠标左右键实现拖动。" & vbCrLf & "　　　　浮预览窗内进行部分键盘及鼠标操作同步作用于相应窗体。", New FontFamily("SimSun"), 13)
        Dialog.ShowDialog()
    End Sub
    Private Sub ShowMe()
        Me.Show()
        SetWindowShow(New WindowInteropHelper(Me).Handle)
        SetForegroundWindow(New WindowInteropHelper(Me).Handle)
    End Sub
    Private Sub HideMe()
        SetWindowHide(New WindowInteropHelper(Me).Handle)
        NotifyIcon.Visible = False
    End Sub
    Private Sub CloseMe()
        SetWindowHide(New WindowInteropHelper(Me).Handle)
    End Sub
    Private Sub ExitMe()
        If Not NotifyIcon Is Nothing Then
            NotifyIcon.Visible = False
        End If
        End
    End Sub

    Private Sub Me_Loaded(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles Me.Loaded
        If IsVerify Then
            LoadSystemMenu()
            LoadNotifyMenu()
            RefreshTimer.Start()
        Else
            Dim ErrorTipTextBlock As GlowTextBlock = New GlowTextBlock("本工具尚未获得本机授权，所有功能禁止使用！", New FontFamily("SimSun"), 14)
            ErrorTipTextBlock.Margin = New Thickness(3)
            ErrorTipTextBlock.Height = 16
            ErrorTipTextBlock.TextAlignment = TextAlignment.Center
            StackPanel.Children.Add(ErrorTipTextBlock)
            Dim MachineIdTextBlock As GlowTextBlock = New GlowTextBlock(GetMachineId(), New FontFamily("SimSun"), 28)
            MachineIdTextBlock.Margin = New Thickness(3)
            MachineIdTextBlock.Height = 30
            MachineIdTextBlock.TextAlignment = TextAlignment.Center
            AddHandler MachineIdTextBlock.MouseUp, AddressOf CopyMachineId
            StackPanel.Children.Add(MachineIdTextBlock)
            Dim CopyTipTextBlock As GlowTextBlock = New GlowTextBlock("鼠标左键点击以上机器码可复制到剪贴板", New FontFamily("SimSun"), 14)
            CopyTipTextBlock.Margin = New Thickness(3)
            CopyTipTextBlock.Height = 16
            CopyTipTextBlock.TextAlignment = TextAlignment.Center
            StackPanel.Children.Add(CopyTipTextBlock)
            UpdateHeight()
        End If
    End Sub
    Private Sub CopyMachineId(ByVal sender As Object, ByVal e As System.Windows.Input.MouseButtonEventArgs)
        Try
            Clipboard.SetText(CType(sender, TextBlock).Text)
        Catch ex As Exception
        End Try
    End Sub
    Private Sub UpdateHeight()
        Dim Height As Double = 0
        For i As Integer = 0 To StackPanel.Children.Count - 1
            Dim GlowTextBlock As GlowTextBlock = CType(StackPanel.Children(i), GlowTextBlock)
            Height += GlowTextBlock.Height + GlowTextBlock.Margin.Top + GlowTextBlock.Margin.Bottom
        Next
        Dim Position = GetClientToWindow(New WindowInteropHelper(Me).Handle)
        Me.Height = Position.Y + Height
    End Sub
    Private Sub LoadSystemMenu()
        Dim hMenu As IntPtr = GetSystemMenu(New WindowInteropHelper(Me).Handle, 0)
        AppendMenu(hMenu, 0, 0, "隐藏(&H)")
        AppendMenu(hMenu, 0, 1, "关于(&A)")
        AppendMenu(hMenu, 0, 2, "退出(&E)")
    End Sub
    Private Sub LoadNotifyMenu()
        Dim CloseMenuItem As Forms.MenuItem = New Forms.MenuItem
        CloseMenuItem.Index = 0
        CloseMenuItem.Text = "关闭(&C)"
        AddHandler CloseMenuItem.Click, AddressOf CloseMenuItem_Click
        NotifyIconMenu.MenuItems.Add(CloseMenuItem)
        Dim HideMenuItem As Forms.MenuItem = New Forms.MenuItem
        HideMenuItem.Index = 1
        HideMenuItem.Text = "隐藏(&H)"
        AddHandler HideMenuItem.Click, AddressOf HideMenuItem_Click
        NotifyIconMenu.MenuItems.Add(HideMenuItem)
        Dim AboutMenuItem As Forms.MenuItem = New Forms.MenuItem
        AddHandler AboutMenuItem.Click, AddressOf AboutMenuItem_Click
        AboutMenuItem.Index = 2
        AboutMenuItem.Text = "关于(&A)"
        NotifyIconMenu.MenuItems.Add(AboutMenuItem)
        Dim ExitMenuItem As Forms.MenuItem = New Forms.MenuItem
        AddHandler ExitMenuItem.Click, AddressOf ExitMenuItem_Click
        ExitMenuItem.Index = 3
        ExitMenuItem.Text = "退出(&E)"
        NotifyIconMenu.MenuItems.Add(ExitMenuItem)
    End Sub
    Private Sub CloseMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        CloseMe()
    End Sub
    Private Sub HideMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        HideMe()
    End Sub
    Private Sub AboutMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        ShowAbout()
    End Sub
    Private Sub ExitMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        ExitMe()
    End Sub
    Private Sub RefreshTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs)
        RefreshFore()
        RefreshInfo()
        DoMissions()
    End Sub
    Private Sub RefreshFore()
        If Origin <> IntPtr.Zero Then
            SetForegroundWindow(Origin)
            Fore = Origin
            Origin = IntPtr.Zero
        Else
            Fore = GetForegroundWindow()
        End If
    End Sub
    Private Sub RefreshInfo()
        Dim Hwnds As List(Of IntPtr) = New List(Of IntPtr)
        Dim Hwnd As IntPtr = IntPtr.Zero
        If Not WindowClassList Is Nothing Then
            For i As Integer = 0 To WindowClassList.Length - 1
                If Not WindowTitleList Is Nothing Then
                    For j As Integer = 0 To WindowTitleList.Length - 1
                        Do
                            Hwnd = FindWindowEx(IntPtr.Zero, Hwnd, WindowClassList(i), WindowTitleList(j))
                            If Hwnd <> IntPtr.Zero Then
                                Hwnds.Add(Hwnd)
                            Else
                                Exit Do
                            End If
                        Loop
                    Next
                End If
            Next
        End If
        Dim IsChanged As Boolean = False
        Dim r As Integer = 0
        For i As Integer = 0 To UBound(Infos)
            If Not Hwnds.Contains(Infos(i - r).Handle) Then
                RemoveList(Infos(i - r).Handle)
                r += 1
                IsChanged = True
            End If
        Next
        For i As Integer = 0 To Hwnds.Count - 1
            If Not InList(Infos, Hwnds(i)) Then
                AddList(Hwnds(i))
                IsChanged = True
            End If
        Next
        For i As Integer = 0 To UBound(Infos)
            Dim Rect As RECT
            GetClientRect(Infos(i).Handle, Rect)
            Infos(i).Rect = New RECT(Rect.Left, Rect.Top, Rect.Right, Rect.Bottom)
            Infos(i).Size = (Infos(i).Rect.Right - Infos(i).Rect.Left) & "×" & (Infos(i).Rect.Bottom - Infos(i).Rect.Top)
            Infos(i).Active = (Fore = Infos(i).Handle)
            Dim aa = IsMoveWindowHide(Infos(i).Handle)
            Dim bb = IsWindowVisible(Infos(i).Handle)
            Infos(i).Hide = IsMoveWindowHide(Infos(i).Handle) OrElse IsWindowVisible(Infos(i).Handle) = 0
            Infos(i).Hung = CInt(IIf(IsHungAppWindow(Infos(i).Handle), Infos(i).Hung + 1, 0))
        Next
        For i As Integer = 0 To StackPanel.Children.Count - 1
            If Not Funcs.ContainsKey(Infos(i).Size) Then
                AddFunc(Infos(i).Size, "")
            End If
            If Not Infos(i).Mode < Funcs(Infos(i).Size).Count Then
                Infos(i).Mode = 0
                Infos(i).Tick = 0
            End If
            Dim TextBlock As GlowTextBlock = CType(StackPanel.Children(i), GlowTextBlock)
            TextBlock.Text = "窗体" & i & " - " & IntegerToHex(Infos(i).Handle) & " - " & Infos(i).Size & " - " & GetStatus(Infos(i)) & IIf(Funcs(Infos(i).Size).Keys(Infos(i).Mode) <> "", " - " & Funcs(Infos(i).Size).Keys(Infos(i).Mode) & " " & Infos(i).Tick & "/" & Funcs(Infos(i).Size).Values(Infos(i).Mode).Count, "")
            TextBlock.Tag = i
        Next
        If IsChanged Then
            UpdateHeight()
        End If
    End Sub
    Private Function InList(ByVal Infos As Info(), ByVal Hwnd As IntPtr) As Boolean
        For Each i As Info In Infos
            If i.Handle = Hwnd Then
                Return True
            End If
        Next
        Return False
    End Function
    Private Sub AddList(ByVal Hwnd As IntPtr)
        ReDim Preserve Infos(0 To (UBound(Infos) + 1))
        Infos(UBound(Infos)).Handle = Hwnd
        Dim TextBlock As GlowTextBlock = New GlowTextBlock("", New FontFamily("SimSun"), 14)
        TextBlock.Margin = New Thickness(3)
        TextBlock.Height = 16
        AddHandler TextBlock.MouseUp, AddressOf TextBlock_MouseUp
        AddHandler TextBlock.PreviewMouseDown, AddressOf TextBlock_PreviewMouseDown
        TextBlock.Preview = New PreviewWindow(Infos(UBound(Infos)).Handle, PreviewSize, PreviewTopmost, Me)
        StackPanel.Children.Add(TextBlock)
    End Sub
    Private Sub RemoveList(ByVal Hwnd As IntPtr)
        For i As Integer = 0 To UBound(Infos)
            If Infos(i).Handle = Hwnd Then
                For j As Integer = i To UBound(Infos) - 1
                    Infos(j) = Infos(j + 1)
                Next
                Dim TextBlock As GlowTextBlock = CType(StackPanel.Children(StackPanel.Children.Count - 1), GlowTextBlock)
                RemoveHandler TextBlock.MouseUp, AddressOf TextBlock_MouseUp
                RemoveHandler TextBlock.PreviewMouseDown, AddressOf TextBlock_PreviewMouseDown
                TextBlock.Preview.Close()
                StackPanel.Children.Remove(TextBlock)
                TextBlock = Nothing
                ReDim Preserve Infos(0 To (UBound(Infos) - 1))
                Exit For
            End If
        Next
    End Sub
    Private Sub DoMissions()
        For i As Integer = 0 To UBound(Infos)
            Dim p1 As Integer = Funcs(Infos(i).Size).Values(Infos(i).Mode)(Infos(i).Tick).Param1
            Dim p2 As Integer = Funcs(Infos(i).Size).Values(Infos(i).Mode)(Infos(i).Tick).Param2
            Dim p3 As Integer = Funcs(Infos(i).Size).Values(Infos(i).Mode)(Infos(i).Tick).Param3
            If p1 > 0 Then
                Select Case p1
                    Case WindowsMessage.WM_KeyDown, WindowsMessage.WM_SysKeyDown, WindowsMessage.WM_KeyUp, WindowsMessage.WM_SysKeyUp
                        Dim Extend As Integer = p2 / &H10000
                        Dim Key As Integer = p2 Mod &H10000
                        Select Case Extend
                            Case PostKeyExtend.PK_Activate
                                PostMessage(Infos(i).Handle, WindowsMessage.WM_Activate, 2, 0)
                                keybd_event(Key, 0, CInt(IIf(p1 = WindowsMessage.WM_KeyDown OrElse p1 = WindowsMessage.WM_SysKeyDown, KEYEVENTF_KEYDOWN, KEYEVENTF_KEYUP)), 0)
                            Case PostKeyExtend.PK_Focus
                                If Infos(i).Handle <> Fore Then
                                    SetForegroundWindow(Infos(i).Handle)
                                    Origin = Fore
                                End If
                                keybd_event(Key, 0, CInt(IIf(p1 = WindowsMessage.WM_KeyDown OrElse p1 = WindowsMessage.WM_SysKeyDown, KEYEVENTF_KEYDOWN, KEYEVENTF_KEYUP)), 0)
                        End Select
                        PostMessage(Infos(i).Handle, p1, Key, p3)
                    Case Else
                        PostMessage(Infos(i).Handle, p1, p2, p3)
                End Select
            End If
            Infos(i).Tick = CInt(IIf(Infos(i).Tick < Funcs(Infos(i).Size).Values(Infos(i).Mode).Count - 1, Infos(i).Tick + 1, 0))
        Next
    End Sub

    Private Sub Me_SourceInitialized(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SourceInitialized
        HwndSource.FromHwnd(New WindowInteropHelper(Me).Handle).AddHook(New HwndSourceHook(AddressOf WndProc))
    End Sub
    Private Function WndProc(ByVal Hwnd As IntPtr, ByVal Msg As Integer, ByVal WParam As Integer, ByVal LParam As Integer, ByRef Handled As Boolean) As IntPtr
        Select Case Msg
            Case WindowsMessage.WM_WindowPosChanged
                NotifyIcon.Visible = True
            Case WindowsMessage.WM_SysCommand
                Select Case WParam
                    Case 0
                        HideMe()
                    Case 1
                        ShowAbout()
                    Case 2
                        ExitMe()
                End Select
        End Select
    End Function

    Private Sub TextBlock_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Input.MouseButtonEventArgs)
        Dim i = CInt(CType(sender, TextBlock).Tag)
        Select Case e.ChangedButton
            Case MouseButton.Right, MouseButton.XButton1
                Infos(i).Mode = CInt(IIf(Infos(i).Mode < Funcs(Infos(i).Size).Count - 1, Infos(i).Mode + 1, 0))
                Infos(i).Tick = 0
            Case MouseButton.Left, MouseButton.XButton2
                Infos(i).Mode = CInt(IIf(Infos(i).Mode > 0, Infos(i).Mode - 1, Funcs(Infos(i).Size).Count - 1))
                Infos(i).Tick = 0
            Case MouseButton.Middle
                If Not Infos(i).Hung Then
                    If Infos(i).Hide Then
                        If IsMoveWindowHide(Infos(i).Handle) Then
                            MoveWindowShow(Infos(i).Handle)
                        Else
                            SetWindowShow(Infos(i).Handle)
                        End If
                    Else
                        If IsShiftDown() Then
                            MoveWindowHide(Infos(i).Handle)
                        Else
                            SetWindowHide(Infos(i).Handle)
                        End If
                    End If
                End If
        End Select
    End Sub
    Private Sub TextBlock_PreviewMouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.MouseButtonEventArgs)
        If e.ClickCount = 3 Then
            Dim i = CInt(CType(sender, TextBlock).Tag)
            SetWindowKill(Infos(i).Handle)
        End If
    End Sub

End Class