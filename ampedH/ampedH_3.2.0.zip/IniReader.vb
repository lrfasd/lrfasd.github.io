﻿Option Explicit On
Option Strict Off

Public Class IniReader

    Private _Ini As String = ""

    Public Sub New(ByVal Path As String)
        If System.IO.File.Exists(Path) Then
            _Ini = System.IO.File.ReadAllText(Path, Text.Encoding.Unicode).Replace(vbLf, vbCr).Replace(vbCr & vbCr, vbCr).Replace(vbCr, vbCrLf)
        End If
    End Sub

    Private Function ExtractString(ByVal Source As String, ByVal Find1 As String, ByVal Find2 As String, ByRef Start As Integer, Optional ByVal FindCount As Integer = 1, Optional ByVal DefaultValue As String = "") As String
        Dim Result As String = DefaultValue
        If Source = "" Then
            Return Result
        End If
        Dim Count As Integer = 0
        While Count < FindCount
            Dim Location1 As Integer = InStr(Start, Source, Find1)
            Dim Location2 As Integer = 0
            If Location1 <> 0 Then
                Location2 = InStr(Location1 + 1, Source, Find2)
                Location1 = InStrRev(Source, Find1, Location2 - 1)
                Result = Mid(Source, Location1 + Find1.Length, CInt(IIf(Location2 <> 0, Location2 - Location1 - Find1.Length, Source.Length - Location1 - Find1.Length + 1)))
                If Location2 <> 0 Then Start = Location2
                Count += 1
            Else
                Result = DefaultValue
                Exit While
            End If
        End While
        Return Result
    End Function

    Public Function ReadString(ByVal Section As String, ByVal Key As String, Optional ByVal DefaultValue As String = "") As String
        Dim Result As String = DefaultValue
        If _Ini = "" Then Return Result
        Dim Sec = ExtractString(_Ini & vbCrLf & "[", "[" & Section & "]" & vbCrLf, vbCrLf & "[", 1)
        Dim Value = ExtractString(Sec & vbCrLf, Key & "=", vbCrLf, 1)
        If Value <> "" Then Result = Value
        Return Result
    End Function
    Public Function ReadInteger(ByVal Section As String, ByVal Key As String, Optional ByVal DefaultValue As Integer = 0) As Integer
        Dim Result As Integer = DefaultValue
        Dim Value = CInt(ReadString(Section, Key, "0"))
        If Value <> 0 Then Result = Value
        Return Result
    End Function
    Public Function ReadFloat(ByVal Section As String, ByVal Key As String, Optional ByVal DefaultValue As Double = 0) As Double
        Dim Result As Double = DefaultValue
        Dim Value = CDbl(ReadString(Section, Key, "0"))
        If Value <> 0 Then Result = Value
        Return Result
    End Function

    Public Function ReadSections() As List(Of String)
        Dim Result As List(Of String) = New List(Of String)
        Dim p As Integer = 1
        Do
            Dim Section As String = ExtractString(vbCrLf & _Ini, vbCrLf & "[", "]", p)
            If Section <> "" Then
                If InStr(Section, vbCrLf) = 0 Then
                    Result.Add(Section)
                End If
            Else
                Exit Do
            End If
        Loop
        Return Result
    End Function
    Public Function ReadKeys(ByVal Section As String) As List(Of String)
        Dim Result As List(Of String) = New List(Of String)
        Dim Sec = ExtractString(_Ini & vbCrLf & "[", "[" & Section & "]" & vbCrLf, vbCrLf & "[", 1)
        Dim p As Integer = 1
        Do
            Dim Key As String = ExtractString(vbCrLf & Sec, vbCrLf, "=", p)
            If Key <> "" Then
                Result.Add(Key)
            Else
                Exit Do
            End If
        Loop
        Return Result
    End Function

    Public Function ReadLine(ByVal Index As Integer) As String
        Return ExtractString(vbCrLf & _Ini, vbCrLf, vbCrLf, 1, Index + 1)
    End Function
    Public Function ReadComment(ByVal Index As Integer) As String
        Dim Result As String = ReadLine(0)
        If Result.Substring(0, 1) = ";" Then
            Result = Result.Substring(1, Result.Length - 1)
        Else
            Result = ""
        End If
        Return Result
    End Function

    Public Function ReadAllSection(ByVal Section As String, ByRef Result As Dictionary(Of String, String)) As Dictionary(Of String, String)
        Dim Keys = ReadKeys(Section)
        For i As Integer = 0 To Keys.Count - 1
            Dim Value = ReadString("Script", Keys(i))
            If Result.ContainsKey(Keys(i)) Then
                Result(Keys(i)) = Value
            Else
                Result.Add(Keys(i), Value)
            End If
        Next
        Return Result
    End Function

End Class
