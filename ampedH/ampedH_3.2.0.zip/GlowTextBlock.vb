﻿Option Explicit On
Option Strict Off

Imports System.Windows.Media.Effects
Imports System.Windows.Interop
Imports System.Windows.Threading

Public Class GlowTextBlock
    Inherits TextBlock

    Private _Preview As PreviewWindow
    Private _Timer As DispatcherTimer = New DispatcherTimer
    Private _IsLButtonDown As Boolean
    Private _IsRButtonDown As Boolean
    Private _IsDoing As Boolean

    Public Sub New(ByVal Text As String, ByVal FontFamily As FontFamily, ByVal FontSize As Double)
        Me.UseLayoutRounding = True
        Me.FontFamily = FontFamily
        Me.FontSize = FontSize
        Me.Text = Text
        Dim DropShadowEffect As DropShadowEffect = New DropShadowEffect
        DropShadowEffect.Color = Colors.White
        DropShadowEffect.ShadowDepth = 0
        DropShadowEffect.BlurRadius = FontSize
        Me.Effect = DropShadowEffect
        AddHandler _Timer.Tick, AddressOf Timer_Tick
    End Sub

    Public Property Preview As PreviewWindow
        Get
            Return _Preview
        End Get
        Set(ByVal value As PreviewWindow)
            _Preview = value
        End Set
    End Property

    Private Sub Me_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.MouseButtonEventArgs) Handles Me.MouseDown
        If _IsDoing Then
            _IsDoing = False
            _IsLButtonDown = False
            _IsRButtonDown = False
        End If
        Select Case e.ChangedButton
            Case MouseButton.Left
                _IsLButtonDown = True
            Case MouseButton.Right
                _IsRButtonDown = True
        End Select
        If _IsLButtonDown AndAlso _IsRButtonDown Then
            _IsDoing = True
            If Not _Preview Is Nothing Then
                If _Preview.IsVisible Then
                    If _Preview.IsHitTestVisible Then
                        _Preview.Hide()
                    Else
                        _Preview.IsHitTestVisible = True
                    End If
                Else
                    _Preview.IsHitTestVisible = True
                    _Preview.ShowPreview()
                End If
            End If
        End If
    End Sub
    Private Sub Me_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Input.MouseButtonEventArgs) Handles Me.MouseUp
        Select Case e.ChangedButton
            Case MouseButton.Left
                _IsLButtonDown = False
            Case MouseButton.Right
                _IsRButtonDown = False
        End Select
        If _IsDoing Then
            e.Handled = True
            If Not _IsLButtonDown AndAlso Not _IsRButtonDown Then
                _IsDoing = False
            End If
        End If
    End Sub

    Private Sub Me_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Input.MouseEventArgs) Handles Me.MouseMove
        If IsShiftDown() Then
            If Not _Preview Is Nothing Then
                If Not _Preview.IsVisible Then
                    _Preview.IsHitTestVisible = False
                    _Preview.ShowPreview()
                    _Timer.Start()
                End If
            End If
        End If
    End Sub
    Private Sub Timer_Tick(ByVal sender As Object, ByVal e As System.EventArgs)
        If Not IsShiftDown() Then
            _Timer.Stop()
            If Not _Preview Is Nothing Then
                If _Preview.IsVisible Then
                    If Not _Preview.IsHitTestVisible Then
                        _Preview.Hide()
                    End If
                End If
            End If
        End If
    End Sub

End Class

